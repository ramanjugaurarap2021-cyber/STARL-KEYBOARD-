package com.starl.keyboard

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Layer { Letters, Symbols, MoreSymbols }
enum class Shift { Off, Once, Caps }

/** Observable UI state shared between the IME service and the Compose keyboard. */
class KeyboardState {
    var layer by mutableStateOf(Layer.Letters)
    var shift by mutableStateOf(Shift.Off)
    var enterLabel by mutableStateOf("⏎")
    var haptics by mutableStateOf(true)
}

/** Callbacks from the keyboard UI into the input connection. */
interface KeyActions {
    fun text(s: String)
    fun backspace()
    fun enter()
}
