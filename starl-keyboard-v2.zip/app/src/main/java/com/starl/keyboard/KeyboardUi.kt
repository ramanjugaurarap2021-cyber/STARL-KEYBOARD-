package com.starl.keyboard

import android.os.SystemClock
import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private val LocalHaptics = staticCompositionLocalOf { true }

private val KeyHeight = 50.dp
private val NumberHeight = 42.dp

private val LetterRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
private val SymbolRows = listOf("@#\$_&-+()/", "*\"':;!?\\=", "~`|{}^%")
private val MoreRows = listOf("[]<>#+*=-_", "€£¥¢•°±÷×", "¿¡§©®™…")

@Composable
fun StarlKeyboard(state: KeyboardState, actions: KeyActions) {
    StarlTheme {
        CompositionLocalProvider(LocalHaptics provides state.haptics) {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Row(Modifier.fillMaxWidth().height(NumberHeight)) {
                        "1234567890".forEach { c ->
                            CharKey(c.toString(), Modifier.weight(1f), fontSize = 18.sp, onKey = actions::text)
                        }
                    }
                    AnimatedContent(
                        targetState = state.layer,
                        transitionSpec = {
                            (fadeIn(tween(180, delayMillis = 40)) + scaleIn(tween(220), initialScale = 0.94f))
                                .togetherWith(fadeOut(tween(100)))
                        },
                        label = "layer",
                    ) { layer ->
                        Column {
                            when (layer) {
                                Layer.Letters -> LettersLayer(state, actions)
                                Layer.Symbols -> SymbolsLayer(SymbolRows, "=\\<", Layer.MoreSymbols, state, actions)
                                Layer.MoreSymbols -> SymbolsLayer(MoreRows, "?123", Layer.Symbols, state, actions)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LettersLayer(state: KeyboardState, a: KeyActions) {
    val up = state.shift != Shift.Off
    fun cased(c: Char) = if (up) c.uppercase() else c.toString()
    var lastShiftTap by remember { mutableLongStateOf(0L) }

    Row(RowMod) { LetterRows[0].forEach { CharKey(cased(it), Modifier.weight(1f), onKey = a::text) } }
    Row(RowMod) {
        Spacer(Modifier.weight(0.5f))
        LetterRows[1].forEach { CharKey(cased(it), Modifier.weight(1f), onKey = a::text) }
        Spacer(Modifier.weight(0.5f))
    }
    Row(RowMod) {
        FnKey(
            label = if (state.shift == Shift.Caps) "⇪" else "⇧",
            modifier = Modifier.weight(1.5f),
            active = up,
        ) {
            val now = SystemClock.uptimeMillis()
            state.shift = when {
                state.shift == Shift.Caps -> Shift.Off
                now - lastShiftTap < 350 -> Shift.Caps
                state.shift == Shift.Once -> Shift.Off
                else -> Shift.Once
            }
            lastShiftTap = now
        }
        LetterRows[2].forEach { CharKey(cased(it), Modifier.weight(1f), onKey = a::text) }
        FnKey("⌫", Modifier.weight(1.5f), repeat = true) { a.backspace() }
    }
    BottomRow(state, a, "?123", Layer.Symbols)
}

@Composable
private fun SymbolsLayer(
    rows: List<String>,
    toggleLabel: String,
    toggleTarget: Layer,
    state: KeyboardState,
    a: KeyActions,
) {
    Row(RowMod) { rows[0].forEach { CharKey(it.toString(), Modifier.weight(1f), onKey = a::text) } }
    Row(RowMod) {
        Spacer(Modifier.weight(0.5f))
        rows[1].forEach { CharKey(it.toString(), Modifier.weight(1f), onKey = a::text) }
        Spacer(Modifier.weight(0.5f))
    }
    Row(RowMod) {
        FnKey(toggleLabel, Modifier.weight(1.5f)) { state.layer = toggleTarget }
        rows[2].forEach { CharKey(it.toString(), Modifier.weight(1f), onKey = a::text) }
        FnKey("⌫", Modifier.weight(1.5f), repeat = true) { a.backspace() }
    }
    BottomRow(state, a, "ABC", Layer.Letters)
}

@Composable
private fun BottomRow(state: KeyboardState, a: KeyActions, leftLabel: String, leftTarget: Layer) {
    Row(RowMod) {
        FnKey(leftLabel, Modifier.weight(1.5f)) { state.layer = leftTarget }
        CharKey(",", Modifier.weight(1f), onKey = a::text)
        KeyButton(
            Modifier.weight(5f),
            MaterialTheme.colorScheme.surfaceContainerHighest,
            MaterialTheme.colorScheme.onSurface,
            onPress = { a.text(" ") },
        ) { Text("Starl", fontSize = 13.sp, modifier = Modifier.alpha(0.5f)) }
        CharKey(".", Modifier.weight(1f), onKey = a::text)
        KeyButton(
            Modifier.weight(1.5f),
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.onPrimary,
            onPress = { a.enter() },
        ) { Text(state.enterLabel, fontSize = if (state.enterLabel.length > 1) 14.sp else 20.sp) }
    }
}

private val RowMod = Modifier.fillMaxWidth().height(KeyHeight)

@Composable
private fun CharKey(
    label: String,
    modifier: Modifier,
    fontSize: TextUnit = 22.sp,
    onKey: (String) -> Unit,
) {
    KeyButton(
        modifier,
        MaterialTheme.colorScheme.surfaceContainerHighest,
        MaterialTheme.colorScheme.onSurface,
        onPress = { onKey(label) },
    ) { Text(label, fontSize = fontSize) }
}

@Composable
private fun FnKey(
    label: String,
    modifier: Modifier,
    repeat: Boolean = false,
    active: Boolean = false,
    onPress: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    KeyButton(
        modifier,
        if (active) cs.primary else cs.secondaryContainer,
        if (active) cs.onPrimary else cs.onSecondaryContainer,
        repeat = repeat,
        onPress = onPress,
    ) { Text(label, fontSize = 18.sp) }
}

/** A key with spring scale, shape morph and colour animation; fires on press, optionally repeating. */
@Composable
private fun KeyButton(
    modifier: Modifier,
    container: Color,
    content: Color,
    repeat: Boolean = false,
    onPress: () -> Unit,
    label: @Composable () -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val scale by animateFloatAsState(
        if (pressed) 0.9f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "scale",
    )
    val bg by animateColorAsState(if (pressed) cs.primaryContainer else container, tween(90), label = "bg")
    val fg by animateColorAsState(if (pressed) cs.onPrimaryContainer else content, tween(90), label = "fg")
    val corner by animateDpAsState(if (pressed) 20.dp else 14.dp, label = "corner")

    val view = LocalView.current
    val haptics = LocalHaptics.current
    val scope = rememberCoroutineScope()
    val press by rememberUpdatedState(onPress)

    Box(
        modifier
            .fillMaxHeight()
            .padding(2.5.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .background(bg, RoundedCornerShape(corner))
            .pointerInput(repeat, haptics) {
                detectTapGestures(onPress = {
                    pressed = true
                    if (haptics) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    press()
                    val job = if (repeat) scope.launch {
                        delay(380)
                        while (isActive) { press(); delay(45) }
                    } else null
                    try {
                        tryAwaitRelease()
                    } finally {
                        job?.cancel()
                        pressed = false
                    }
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        CompositionLocalProvider(LocalContentColor provides fg) { label() }
    }
}
