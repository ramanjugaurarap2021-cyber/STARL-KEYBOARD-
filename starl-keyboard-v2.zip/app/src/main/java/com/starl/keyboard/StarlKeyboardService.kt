package com.starl.keyboard

import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class StarlKeyboardService :
    InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry

    private val state = KeyboardState()
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("starl", MODE_PRIVATE)
        savedState.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    override fun onDestroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        window.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }
        return ComposeView(this).apply {
            setContent { StarlKeyboard(state, actions) }
        }
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        state.haptics = prefs.getBoolean("haptics", true)
        state.enterLabel = enterLabelFor(info)
        if (!restarting) {
            state.layer = when (info.inputType and InputType.TYPE_MASK_CLASS) {
                InputType.TYPE_CLASS_NUMBER, InputType.TYPE_CLASS_PHONE -> Layer.Symbols
                else -> Layer.Letters
            }
            state.shift = Shift.Off
        }
        refreshShift()
    }

    private val actions = object : KeyActions {
        override fun text(s: String) {
            currentInputConnection?.commitText(s, 1)
            if (state.shift == Shift.Once) state.shift = Shift.Off
            refreshShift()
        }

        override fun backspace() {
            val ic = currentInputConnection ?: return
            if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
            else ic.deleteSurroundingTextInCodePoints(1, 0)
            refreshShift()
        }

        override fun enter() {
            val ic = currentInputConnection ?: return
            val info = currentInputEditorInfo
            val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
            val noAction = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
            } else {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            }
            refreshShift()
        }
    }

    /** Auto-capitalise at sentence starts, unless caps lock is on. */
    private fun refreshShift() {
        if (state.shift == Shift.Caps) return
        val type = currentInputEditorInfo?.inputType ?: return
        if (type == InputType.TYPE_NULL) return
        val caps = currentInputConnection?.getCursorCapsMode(type) ?: 0
        state.shift = if (caps != 0) Shift.Once else Shift.Off
    }

    private fun enterLabelFor(info: EditorInfo): String {
        if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "⏎"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "⏎"
        }
    }
}
