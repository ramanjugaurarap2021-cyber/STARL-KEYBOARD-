# ✦ Starl Keyboard

A free, open-source Android keyboard built with Kotlin, Jetpack Compose and Material 3 (Material You dynamic colors), with spring-based fluid animations.

## Features
- QWERTY letters, number row, two symbol pages
- Shift, double-tap caps lock, sentence auto-capitalisation
- Backspace with press-and-hold repeat
- Context-aware Enter key (Go / Search / Send / Next / Done)
- Number/phone fields open the symbols page automatically
- Spring press animation, shape morph, animated layer transitions
- Dynamic color + light/dark theme, haptic feedback toggle

## Build
Open in Android Studio (Ladybug or newer) and run, or:

```bash
gradle wrapper --gradle-version 8.9   # first time only
./gradlew assembleDebug
```

Then open the app, tap **Enable Starl Keyboard**, then **Switch to Starl**.

## Roadmap
Key preview popups, long-press accents, emoji panel, suggestions/autocorrect, swipe typing, clipboard history, themes, more languages.

## Contributing
Issues and PRs are welcome. Licensed under MIT.
